<!-- Footer.php -->
</div> <!-- Close the content div -->
    </div> <!-- Close the container div -->

    <div id="footer" style="width: 100%; background-color: #333; color: white; text-align: center; padding: 10px; position: fixed; bottom: 0;">
        <p>Student Number: <b>040982818<b> | First Name: Hamza | Last Name: El Sousi  | Email: elso0011@algonquinlive.com</p>
    </div>
</body>
</html>
