<!-- Header.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab 8</title>
    <!-- Add any additional styles or scripts here -->
</head>
<body>
    <div id="header" style="width: 100%; background-color: #333; color: white; text-align: center; padding: 10px;">
        <h1>CET Computer Science</h1>
        <h2>Web Programming</h2>
    </div>

    <div id="container" style="display: flex;">
        <div id="menu" style="width: 20%; background-color: #f2f2f2; padding: 20px; height: 100vh;">
            <!-- Include Menu.php content here -->
            <?php include('Menu.php'); ?>
        </div>
        <div id="content" style="width: 80%; padding: 20px;">
            <!-- Content of the pages will be dynamically loaded here -->
