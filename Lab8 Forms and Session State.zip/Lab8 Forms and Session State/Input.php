<!-- Input.php -->
<?php include 'Header.php'; ?>
<!-- -->

<section>
    <div style="width: 50%; float: left;">
        <form action="" method="post">
            <!-- Form inputs -->
            <label for="first_name">First Name:  </label>
            <input type="text" id="first_name" name="first_name" required>
            <br>
            <label for="last_name">Last Name:  </label>
            <input type="text" id="last_name" name="last_name" required>
            <br>
            <label for="Phone">Phone Number:</label>
            <input type="number" id="Phone" name="Phone">
            <br>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            <br>
            <label for="birth_day">Birth Day:  </label>
            <input type="date" id="birth_day" name="birth_day">
            <br>
            <label for="occupation">Occupation:</label>
            <input type="radio" id="student" name="occupation" value="Student"> Student
            <input type="radio" id="doctor" name="occupation" value="Doctor"> Doctor
            <input type="radio" id="farmer" name="occupation" value="Farmer"> Farmer
            <input type="radio" id="engineer" name="occupation" value="Engineer"> Engineer
            <br>
            <label for="favorite_sport">Favorite Sport:</label>
            <select id="favorite_sport" name="favorite_sport">
                <option value="Hockey">Hockey</option>
                <option value="Football">Football</option>
                <option value="Carling">Carling</option>
                <option value="Tennis">Tennis</option>
            </select>
            <br>
            <input type="submit" value="Submit" name="submit">
        </form>
    </div>

    <div style="width: 50%; float: left;">
        <!-- Display results after form submission -->
        <?php
        if(isset($_POST['submit'])){
            // Gather and display form data
            echo "<h2>Form Data:</h2>";
            echo "<p><strong>First Name:</strong> " . $_POST['first_name'] . "</p>";
            echo "<p><strong>Last Name:</strong> " . $_POST['last_name'] . "</p>";
            echo "<p><strong>Phone Number:</strong> " . $_POST['Phone'] . "</p>";
            echo "<p><strong>Email:</strong> " . $_POST['email'] . "</p>";
            echo "<p><strong>Birth Day:</strong> " . $_POST['birth_day'] . "</p>";
            echo "<p><strong>Occupation:</strong> " . $_POST['occupation'] . "</p>";
            echo "<p><strong>Favorite Sport:</strong> " . $_POST['favorite_sport'] . "</p>";
        }
        ?>
    </div>
</section>

<?php include 'Footer.php'; ?>
