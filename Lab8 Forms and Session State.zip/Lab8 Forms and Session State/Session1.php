<!-- Session1.php -->
<?php
    session_start();
    include 'Header.php';
?>

<section>
    <div class="left-section" style="width: 50%; float: left;">
        <!-- Same form as in Input.php -->
        <form action="" method="post">
            <!-- Form inputs -->
            <label for="first_name">First Name:</label>
            <input type="text" id="first_name" name="first_name" required>
            <br>
            <label for="last_name">Last Name:</label>
            <input type="text" id="last_name" name="last_name" required>
            <br>
            <label for="telephone">Telephone Number:</label>
            <input type="number" id="telephone" name="telephone">
            <br>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            <br>
            <label for="birth_day">Birth Day:</label>
            <input type="date" id="birth_day" name="birth_day">
            <br>
            <label for="occupation">Occupation:</label>
            <input type="radio" id="student" name="occupation" value="Student"> Student
            <input type="radio" id="doctor" name="occupation" value="Doctor"> Doctor
            <input type="radio" id="farmer" name="occupation" value="Farmer"> Farmer
            <input type="radio" id="engineer" name="occupation" value="Engineer"> Engineer
            <br>
            <label for="favorite_sport">Favorite Sport:</label>
            <select id="favorite_sport" name="favorite_sport">
                <option value="Hockey">Hockey</option>
                <option value="Football">Football</option>
                <option value="Carling">Carling</option>
                <option value="Tennis">Tennis</option>
            </select>
            <br>
            <input type="submit" value="Submit" name="submit">
        </form>
    </div>

    <div class="right-section" style="width: 50%; float: left;">
    <!-- Display results here after form submission -->
    <?php
    if(isset($_POST['submit'])){
        // Store form data in session
        $_SESSION['first_name'] = $_POST['first_name'];
        $_SESSION['last_name'] = $_POST['last_name'];
        $_SESSION['telephone'] = $_POST['telephone'];
        $_SESSION['email'] = $_POST['email'];
        $_SESSION['birth_day'] = $_POST['birth_day'];
        $_SESSION['occupation'] = $_POST['occupation'];
        $_SESSION['favorite_sport'] = $_POST['favorite_sport'];

        // Redirect to Session2.php
        header("Location: Session2.php");
        exit();
    }
    ?>
    </div>
</section>

<?php include 'Footer.php'; ?>
