<!-- Session2.php -->
<?php
    session_start();
    include 'Header.php';
    // include 'Menu.php';
?>

<section>
    <div class="left-section">
        <!-- Display results from session here -->
        <?php
            if(isset($_SESSION['first_name'])){
                // Display stored session data
                echo "<p>First Name: " . $_SESSION['first_name'] . "</p>";
                echo "<p>Last Name: " . $_SESSION['last_name'] . "</p>";
                echo "<p>Telephone Number: " . $_SESSION['telephone'] . "</p>";
                echo "<p>Email: " . $_SESSION['email'] . "</p>";
                echo "<p>Birth Day: " . $_SESSION['birth_day'] . "</p>";
                echo "<p>Occupation: " . $_SESSION['occupation'] . "</p>";
                echo "<p>Favorite Sport: " . $_SESSION['favorite_sport'] . "</p>";
                // Display other stored session data
            }
        ?>
    </div>
</section>

<?php include 'Footer.php'; ?>
