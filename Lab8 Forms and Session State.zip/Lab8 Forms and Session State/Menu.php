<!-- Menu.php -->
<ul>
    <li><a href="Input.php">Input</a></li>
    <li><a href="Session1.php">Session 1</a></li>
    <li><a href="Session2.php">Session 2</a></li>
</ul>
